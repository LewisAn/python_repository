"""配置选项"""

intels = [
    'facebook.com',
    'github.com',
    'instagram.com',
    'youtube.com',
]

badTypes = [
    'bmp',
    'css',
    'csv',
    'docx',
    'ico',
    'jpeg',
    'jpg',
    'js',
    'json',
    'pdf',
    'png',
    'svg',
    'xls',
    'xml',
]
